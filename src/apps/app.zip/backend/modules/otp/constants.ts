export const OTP_LENGTH = 4;
