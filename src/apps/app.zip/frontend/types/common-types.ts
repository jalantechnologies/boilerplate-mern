export type JsonObject = {
  [key: string]: unknown;
};
